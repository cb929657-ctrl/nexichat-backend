const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const UserSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Name is required'],
    trim: true,
    maxlength: [50, 'Name cannot exceed 50 characters']
  },
  phone: {
    type: String,
    required: [true, 'Phone number is required'],
    unique: true,
    match: [/^\+[1-9]\d{6,14}$/, 'Please enter a valid phone number']
  },
  email: { type: String, sparse: true, lowercase: true },
  password: { type: String, minlength: 6, select: false },
  avatar: {
    url: { type: String, default: '' },
    publicId: { type: String, default: '' }
  },
  about: { type: String, default: 'Hey there! I am using Nexi Chat 🚀', maxlength: 139 },
  isOnline: { type: Boolean, default: false },
  lastSeen: { type: Date, default: Date.now },
  isVerified: { type: Boolean, default: false },
  otp: { type: String, select: false },
  otpExpire: { type: Date, select: false },
  pushToken: { type: String, default: '' },
  privacy: {
    lastSeen: { type: String, enum: ['everyone','contacts','nobody'], default: 'contacts' },
    profilePhoto: { type: String, enum: ['everyone','contacts','nobody'], default: 'contacts' },
    about: { type: String, enum: ['everyone','contacts','nobody'], default: 'everyone' },
    readReceipts: { type: Boolean, default: true }
  },
  blockedUsers: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  contacts: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }]
}, { timestamps: true });

UserSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

UserSchema.methods.matchPassword = async function(enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

module.exports = mongoose.model('User', UserSchema);
