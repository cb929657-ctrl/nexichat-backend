# Nexi Chat — Backend

Node.js + Express + Socket.io + MongoDB backend for Nexi Chat.

## 📁 What's included

```
nexichat-backend/
├── server.js              # Entry point
├── socket.js               # Real-time messaging, typing, calls, online status
├── package.json
├── .env.example             # Copy to .env and fill in your values
├── models/
│   ├── User.js
│   ├── Message.js
│   ├── Conversation.js
│   └── Status.js
├── routes/
│   ├── auth.js              # OTP login, signup, profile setup
│   ├── messages.js          # Send/receive/delete/react to messages
│   ├── groups.js            # Create/manage groups
│   ├── status.js            # Stories feed, view, react
│   └── payments.js          # Mock UPI send/history
└── middleware/
    └── auth.js              # JWT protect + token generator
```

---

## 1. Local setup (test before deploying)

```bash
cd nexichat-backend
npm install
cp .env.example .env
```

Fill in `.env`:
- `MONGODB_URI` — get a free cluster at https://mongodb.com/cloud/atlas (free tier is enough)
- `JWT_SECRET` — any long random string
- Twilio / Cloudinary keys are optional at first — OTP will just print to your server console in dev mode, and you can skip media upload until you're ready

```bash
npm run dev
```

Server runs at `http://localhost:5000`. Visit it in a browser — you should see:
```json
{ "success": true, "message": "Nexi Chat backend is running 🚀" }
```

---

## 2. Deploy to Railway (free tier, easiest option)

1. Go to https://railway.app and sign in with GitHub
2. Push this `nexichat-backend` folder to a new GitHub repo
3. In Railway: **New Project → Deploy from GitHub repo** → select your repo
4. Railway auto-detects Node.js and runs `npm install` + `npm start`
5. Go to your project **Variables** tab and paste in everything from `.env.example` with your real values
6. Under **Settings → Networking**, click **Generate Domain** — this gives you a public URL like `https://nexichat-backend-production.up.railway.app`

That URL is your backend's base URL — you'll use it in the frontend.

### Render.com (alternative, also free tier)
1. https://render.com → **New → Web Service** → connect your GitHub repo
2. Build command: `npm install`  ·  Start command: `npm start`
3. Add the same environment variables under **Environment**
4. Deploy — Render gives you a URL like `https://nexichat-backend.onrender.com`

(Note: Render's free tier sleeps after inactivity, so the first request after idle time will be slow. Railway doesn't have this issue but the free credit runs out monthly.)

---

## 3. MongoDB Atlas (free database, 5 minutes)

1. https://mongodb.com/cloud/atlas → Sign up → **Build a Database** → choose **Free (M0)**
2. Create a database user (username + password)
3. Under **Network Access**, click **Allow access from anywhere** (0.0.0.0/0) — needed since Railway/Render use dynamic IPs
4. Click **Connect → Drivers** and copy the connection string, it looks like:
   ```
   mongodb+srv://username:password@cluster0.xxxxx.mongodb.net/nexichat
   ```
5. Paste this into your `.env` as `MONGODB_URI` (both locally and in Railway/Render's variables)

---

## 4. Connecting the Nexi Chat frontend to this backend

Every screen you have (auth, chat list, chat screen, group chat, calls, status) is currently static HTML/JS with mock data. To make it real, replace the mock logic with calls to this API. Below is exactly what to change in each screen.

### Step A — Add a shared config at the top of every HTML file

```html
<script>
  const API_BASE = 'https://your-backend-url.up.railway.app/api';
  const SOCKET_URL = 'https://your-backend-url.up.railway.app';
  let authToken = localStorage.getItem('nexi_token') || '';
</script>
<script src="https://cdn.socket.io/4.6.1/socket.io.min.js"></script>
```

### Step B — Authentication screen (replace `mockDB` logic)

Where you currently do:
```js
const user = mockDB.users.find(u => u.phone === phone);
```

Replace with:
```js
async function sendOtp(phone) {
  const res = await fetch(`${API_BASE}/auth/send-otp`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ phone })
  });
  return res.json();
}

async function verifyOtp(phone, otp) {
  const res = await fetch(`${API_BASE}/auth/verify-otp`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ phone, otp })
  });
  const data = await res.json();
  if (data.success) {
    authToken = data.token;
    localStorage.setItem('nexi_token', authToken);
    localStorage.setItem('nexi_user', JSON.stringify(data.user));
  }
  return data;
}
```

Call `sendOtp()` when the user submits their phone number (instead of going straight to the OTP screen), then `verifyOtp()` when they enter the 4-digit code. If `data.isNewUser` is true, send them to Profile Setup; otherwise straight to the chat list.

### Step C — Chat list (replace hardcoded contact array)

```js
async function loadConversations() {
  const res = await fetch(`${API_BASE}/messages/conversations`, {
    headers: { Authorization: `Bearer ${authToken}` }
  });
  const data = await res.json();
  return data.conversations; // render these instead of the static array
}
```

### Step D — Chat screen: load history + connect socket

```js
const socket = io(SOCKET_URL, { auth: { token: authToken } });

async function openConversation(conversationId) {
  socket.emit('join_conversation', conversationId);

  const res = await fetch(`${API_BASE}/messages/${conversationId}`, {
    headers: { Authorization: `Bearer ${authToken}` }
  });
  const data = await res.json();
  renderMessages(data.messages); // your existing message-rendering function
}

// Listen for new messages from other users in real time
socket.on('receive_message', (message) => {
  appendMessageToUI(message); // your existing function that adds a bubble
});

// Typing indicator
socket.on('typing_start', ({ conversationId, name }) => showTypingIndicator(name));
socket.on('typing_stop', () => hideTypingIndicator());
```

### Step E — Sending a message (replace `addOutgoingMsg`)

```js
async function sendMessage(conversationId, text) {
  const res = await fetch(`${API_BASE}/messages/${conversationId}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${authToken}` },
    body: JSON.stringify({ type: 'text', content: text })
  });
  const data = await res.json();
  socket.emit('send_message', { conversationId, message: data.message }); // notify others instantly
  appendMessageToUI(data.message); // show it for yourself immediately
}

// When the user is typing
document.getElementById('compInput').addEventListener('input', () => {
  socket.emit('typing_start', { conversationId: currentConversationId });
  clearTimeout(window._typingTimeout);
  window._typingTimeout = setTimeout(() => socket.emit('typing_stop', { conversationId: currentConversationId }), 2000);
});
```

### Step F — Group chat (Step 5 file)

Replace the "Create Group" mock function:
```js
async function createGroup(name, participantIds) {
  const res = await fetch(`${API_BASE}/groups`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${authToken}` },
    body: JSON.stringify({ name, participantIds })
  });
  return res.json();
}
```

### Step G — Status/Stories (Step 6 file)

```js
async function postStatus(type, content, backgroundColor) {
  await fetch(`${API_BASE}/status`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${authToken}` },
    body: JSON.stringify({ type, content, backgroundColor })
  });
}

async function loadStatusFeed() {
  const res = await fetch(`${API_BASE}/status/feed`, { headers: { Authorization: `Bearer ${authToken}` } });
  return (await res.json()).feed;
}
```

### Step H — Voice/Video calls (Step 4 file) — WebRTC signaling

The backend only relays signaling messages (offer/answer/ICE candidates) — the actual audio/video stream goes peer-to-peer via WebRTC, which runs entirely in the browser.

```js
// Caller side
async function startCall(toUserId, callType) {
  const pc = new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] });
  const stream = await navigator.mediaDevices.getUserMedia({ video: callType === 'video', audio: true });
  stream.getTracks().forEach(track => pc.addTrack(track, stream));

  pc.onicecandidate = (e) => { if (e.candidate) socket.emit('ice_candidate', { toUserId, candidate: e.candidate }); };

  const offer = await pc.createOffer();
  await pc.setLocalDescription(offer);
  socket.emit('call_user', { toUserId, offer, callType, fromUser: currentUser });
}

socket.on('call_answered', async ({ answer }) => {
  await pc.setRemoteDescription(answer);
});

socket.on('ice_candidate', ({ candidate }) => {
  pc.addIceCandidate(candidate);
});
```

```js
// Receiver side
socket.on('incoming_call', async ({ offer, callType, fromUser, fromUserId }) => {
  showIncomingCallUI(fromUser, callType); // your existing incoming-call screen
  window._pendingOffer = offer;
  window._pendingCallerId = fromUserId;
});

async function acceptCall() {
  const pc = new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] });
  const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
  stream.getTracks().forEach(track => pc.addTrack(track, stream));

  await pc.setRemoteDescription(window._pendingOffer);
  const answer = await pc.createAnswer();
  await pc.setLocalDescription(answer);
  socket.emit('answer_call', { toUserId: window._pendingCallerId, answer });
}
```

---

## 5. Testing the connection quickly

Once deployed, open your frontend HTML file, open the browser dev console, and run:
```js
fetch('https://your-backend-url.up.railway.app/').then(r => r.json()).then(console.log)
```
You should see `{ success: true, message: "Nexi Chat backend is running 🚀" }`. If you get a CORS error, double-check `CLIENT_URL` in your Railway/Render environment variables matches exactly where your frontend is hosted (or set it to `*` temporarily while testing).

---

## 6. What's still mocked / needs a real provider

- **OTP SMS** — currently logs to console in dev mode. Sign up at https://twilio.com, get a phone number, uncomment the Twilio block in `routes/auth.js`, and add your credentials to `.env`
- **Media uploads** (photos/videos/docs) — sign up at https://cloudinary.com (free tier), and wire up a `multer` + `cloudinary` upload route (ask me and I'll add this next)
- **Payments** — `routes/payments.js` is a working mock ledger between users, not connected to a real bank/UPI rail. For real money movement you'd need a licensed PSP partner (e.g. Razorpay, Cashfree) — this is a serious compliance undertaking, not just a few lines of code
- **Push notifications** — `pushToken` field exists on the User model but nothing sends to it yet; Firebase Cloud Messaging is the usual next step
