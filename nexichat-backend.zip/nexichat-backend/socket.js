const jwt = require('jsonwebtoken');
const User = require('./models/User');

// Track online users: { userId: socketId }
const onlineUsers = new Map();

module.exports = function initSocket(io) {

  // Auth middleware for socket connections
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth?.token;
      if (!token) return next(new Error('Authentication required'));
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const user = await User.findById(decoded.id);
      if (!user) return next(new Error('User not found'));
      socket.userId = user._id.toString();
      socket.user = user;
      next();
    } catch (err) {
      next(new Error('Invalid token'));
    }
  });

  io.on('connection', async (socket) => {
    const userId = socket.userId;
    console.log(`✅ User connected: ${socket.user.name} (${userId})`);

    // Mark online
    onlineUsers.set(userId, socket.id);
    await User.findByIdAndUpdate(userId, { isOnline: true });
    socket.broadcast.emit('user_online', { userId });

    // Join a personal room (for direct notifications)
    socket.join(userId);

    // ---- JOIN CONVERSATION ROOM ----
    socket.on('join_conversation', (conversationId) => {
      socket.join(conversationId);
    });

    socket.on('leave_conversation', (conversationId) => {
      socket.leave(conversationId);
    });

    // ---- SEND MESSAGE (real-time broadcast) ----
    // Client should still POST to /api/messages/:conversationId to persist,
    // then emit this event so other participants get it instantly.
    socket.on('send_message', (data) => {
      // data = { conversationId, message }
      socket.to(data.conversationId).emit('receive_message', data.message);
    });

    // ---- TYPING INDICATOR ----
    socket.on('typing_start', ({ conversationId }) => {
      socket.to(conversationId).emit('typing_start', { conversationId, userId, name: socket.user.name });
    });

    socket.on('typing_stop', ({ conversationId }) => {
      socket.to(conversationId).emit('typing_stop', { conversationId, userId });
    });

    // ---- MESSAGE DELIVERED / READ ----
    socket.on('message_delivered', ({ conversationId, messageId }) => {
      socket.to(conversationId).emit('message_delivered', { messageId, userId });
    });

    socket.on('message_read', ({ conversationId, messageId }) => {
      socket.to(conversationId).emit('message_read', { messageId, userId });
    });

    // ---- REACTIONS ----
    socket.on('react_message', ({ conversationId, messageId, emoji }) => {
      socket.to(conversationId).emit('react_message', { messageId, emoji, userId });
    });

    // ---- VOICE / VIDEO CALL SIGNALING (WebRTC) ----
    socket.on('call_user', ({ toUserId, offer, callType, fromUser }) => {
      const targetSocket = onlineUsers.get(toUserId);
      if (targetSocket) {
        io.to(targetSocket).emit('incoming_call', { offer, callType, fromUser, fromUserId: userId });
      } else {
        socket.emit('call_failed', { message: 'User is offline' });
      }
    });

    socket.on('answer_call', ({ toUserId, answer }) => {
      const targetSocket = onlineUsers.get(toUserId);
      if (targetSocket) io.to(targetSocket).emit('call_answered', { answer, fromUserId: userId });
    });

    socket.on('ice_candidate', ({ toUserId, candidate }) => {
      const targetSocket = onlineUsers.get(toUserId);
      if (targetSocket) io.to(targetSocket).emit('ice_candidate', { candidate, fromUserId: userId });
    });

    socket.on('end_call', ({ toUserId }) => {
      const targetSocket = onlineUsers.get(toUserId);
      if (targetSocket) io.to(targetSocket).emit('call_ended', { fromUserId: userId });
    });

    socket.on('reject_call', ({ toUserId }) => {
      const targetSocket = onlineUsers.get(toUserId);
      if (targetSocket) io.to(targetSocket).emit('call_rejected', { fromUserId: userId });
    });

    // ---- STATUS UPDATES ----
    socket.on('new_status', (statusData) => {
      // Broadcast to contacts only (in production, filter by actual contact list)
      socket.broadcast.emit('new_status', statusData);
    });

    // ---- DISCONNECT ----
    socket.on('disconnect', async () => {
      console.log(`❌ User disconnected: ${socket.user?.name} (${userId})`);
      onlineUsers.delete(userId);
      await User.findByIdAndUpdate(userId, { isOnline: false, lastSeen: new Date() });
      socket.broadcast.emit('user_offline', { userId, lastSeen: new Date() });
    });
  });
};
