const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const Message = require('../models/Message');
const Conversation = require('../models/Conversation');
const cloudinary = require('cloudinary').v2;
const multer = require('multer');

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 50 * 1024 * 1024 } });

// @route  GET /api/messages/:conversationId
// @desc   Get all messages in a conversation
router.get('/:conversationId', protect, async (req, res) => {
  try {
    const { page = 1, limit = 50 } = req.query;
    const messages = await Message.find({
      conversation: req.params.conversationId,
      deletedFor: { $ne: req.user._id },
      isDeleted: false
    })
    .populate('sender', 'name avatar phone')
    .populate('replyTo', 'content type sender media')
    .sort({ createdAt: -1 })
    .limit(limit * 1)
    .skip((page - 1) * limit);

    res.status(200).json({ success: true, messages: messages.reverse(), page: parseInt(page) });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// @route  POST /api/messages
// @desc   Send a text message
router.post('/', protect, async (req, res) => {
  try {
    const { conversationId, content, type = 'text', replyTo, location } = req.body;

    const conversation = await Conversation.findById(conversationId);
    if (!conversation) return res.status(404).json({ success: false, message: 'Conversation not found' });

    // Check disappearing messages
    let disappearsAt = null;
    if (conversation.disappearingMessages.enabled) {
      disappearsAt = new Date(Date.now() + conversation.disappearingMessages.duration * 1000);
    }

    const message = await Message.create({
      conversation: conversationId,
      sender: req.user._id,
      type,
      content,
      replyTo: replyTo || null,
      location: location || undefined,
      disappearsAt
    });

    // Update last message in conversation
    await Conversation.findByIdAndUpdate(conversationId, { lastMessage: message._id });

    // Update unread counts for other participants
    conversation.participants.forEach(async (participantId) => {
      if (participantId.toString() !== req.user._id.toString()) {
        await Conversation.findOneAndUpdate(
          { _id: conversationId, 'unreadCounts.user': participantId },
          { $inc: { 'unreadCounts.$.count': 1 } },
          { upsert: false }
        );
      }
    });

    await message.populate('sender', 'name avatar phone');
    if (replyTo) await message.populate('replyTo', 'content type sender');

    res.status(201).json({ success: true, message });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// @route  POST /api/messages/media
// @desc   Send media message (image, video, audio, document)
router.post('/media', protect, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ success: false, message: 'No file uploaded' });

    const { conversationId, type, content, replyTo } = req.body;

    // Upload to Cloudinary
    const b64 = Buffer.from(req.file.buffer).toString('base64');
    const dataURI = `data:${req.file.mimetype};base64,${b64}`;

    const uploadResult = await cloudinary.uploader.upload(dataURI, {
      resource_type: type === 'video' || type === 'audio' ? 'video' : 'auto',
      folder: `nexichat/${type}s`,
    });

    const message = await Message.create({
      conversation: conversationId,
      sender: req.user._id,
      type,
      content: content || '',
      replyTo: replyTo || null,
      media: {
        url: uploadResult.secure_url,
        publicId: uploadResult.public_id,
        mimeType: req.file.mimetype,
        size: req.file.size,
        duration: uploadResult.duration || 0
      }
    });

    await Conversation.findByIdAndUpdate(conversationId, { lastMessage: message._id });
    await message.populate('sender', 'name avatar phone');

    res.status(201).json({ success: true, message });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// @route  PUT /api/messages/:id/read
// @desc   Mark message as read
router.put('/:id/read', protect, async (req, res) => {
  try {
    const message = await Message.findById(req.params.id);
    if (!message) return res.status(404).json({ success: false, message: 'Message not found' });

    const alreadyRead = message.readBy.some(r => r.user.toString() === req.user._id.toString());
    if (!alreadyRead) {
      message.readBy.push({ user: req.user._id, readAt: new Date() });
      await message.save();
    }

    res.status(200).json({ success: true, message });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// @route  POST /api/messages/:id/react
// @desc   React to a message
router.post('/:id/react', protect, async (req, res) => {
  try {
    const { emoji } = req.body;
    const message = await Message.findById(req.params.id);
    if (!message) return res.status(404).json({ success: false, message: 'Message not found' });

    const existingReaction = message.reactions.find(r => r.user.toString() === req.user._id.toString());
    if (existingReaction) {
      if (existingReaction.emoji === emoji) {
        // Remove reaction
        message.reactions = message.reactions.filter(r => r.user.toString() !== req.user._id.toString());
      } else {
        existingReaction.emoji = emoji;
      }
    } else {
      message.reactions.push({ user: req.user._id, emoji });
    }

    await message.save();
    res.status(200).json({ success: true, message });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// @route  DELETE /api/messages/:id
// @desc   Delete message (for me or everyone)
router.delete('/:id', protect, async (req, res) => {
  try {
    const { deleteFor } = req.body; // 'me' or 'everyone'
    const message = await Message.findById(req.params.id);
    if (!message) return res.status(404).json({ success: false, message: 'Message not found' });

    if (deleteFor === 'everyone' && message.sender.toString() === req.user._id.toString()) {
      message.isDeleted = true;
      message.content = '';
    } else {
      message.deletedFor.push(req.user._id);
    }

    await message.save();
    res.status(200).json({ success: true, message: 'Message deleted' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
