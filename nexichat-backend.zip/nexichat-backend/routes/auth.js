const express = require('express');
const router = express.Router();
const User = require('../models/User');
const { generateToken } = require('../middleware/auth');

// Generate random 4-digit OTP
const generateOTP = () => Math.floor(1000 + Math.random() * 9000).toString();

// @route  POST /api/auth/send-otp
// @desc   Send OTP to phone number
// @access Public
router.post('/send-otp', async (req, res) => {
  try {
    const { phone } = req.body;
    if (!phone) return res.status(400).json({ success: false, message: 'Phone number required' });

    const otp = generateOTP();
    const otpExpire = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

    // Find or create user
    let user = await User.findOne({ phone });
    if (!user) {
      user = new User({ phone, name: 'Nexi User' });
    }
    user.otp = otp;
    user.otpExpire = otpExpire;
    await user.save({ validateBeforeSave: false });

    // Send OTP via Twilio (uncomment in production)
    // const client = require('twilio')(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
    // await client.messages.create({
    //   body: `Your Nexi Chat OTP is: ${otp}. Valid for 10 minutes.`,
    //   from: process.env.TWILIO_PHONE,
    //   to: phone
    // });

    // For development — return OTP in response
    const isDev = process.env.NODE_ENV === 'development';
    res.status(200).json({
      success: true,
      message: 'OTP sent successfully',
      ...(isDev && { otp }) // Only show OTP in development
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// @route  POST /api/auth/verify-otp
// @desc   Verify OTP and login/register user
// @access Public
router.post('/verify-otp', async (req, res) => {
  try {
    const { phone, otp } = req.body;
    if (!phone || !otp) return res.status(400).json({ success: false, message: 'Phone and OTP required' });

    const user = await User.findOne({ phone }).select('+otp +otpExpire');
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });
    if (user.otp !== otp) return res.status(400).json({ success: false, message: 'Invalid OTP' });
    if (user.otpExpire < Date.now()) return res.status(400).json({ success: false, message: 'OTP expired' });

    // Mark verified
    user.isVerified = true;
    user.otp = undefined;
    user.otpExpire = undefined;
    await user.save({ validateBeforeSave: false });

    const token = generateToken(user._id);
    const isNewUser = !user.name || user.name === 'Nexi User';

    res.status(200).json({
      success: true,
      token,
      isNewUser,
      user: {
        _id: user._id,
        name: user.name,
        phone: user.phone,
        avatar: user.avatar,
        about: user.about,
        isVerified: user.isVerified
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// @route  PUT /api/auth/setup-profile
// @desc   Set name and avatar after OTP verification
// @access Private (requires token)
router.put('/setup-profile', require('../middleware/auth').protect, async (req, res) => {
  try {
    const { name, about } = req.body;
    const user = await User.findById(req.user._id);
    if (name) user.name = name;
    if (about) user.about = about;
    await user.save();
    res.status(200).json({ success: true, user });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// @route  GET /api/auth/me
// @desc   Get current user
// @access Private
router.get('/me', require('../middleware/auth').protect, async (req, res) => {
  const user = await User.findById(req.user._id);
  res.status(200).json({ success: true, user });
});

module.exports = router;
